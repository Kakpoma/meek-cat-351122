CREATE TABLE "appointments" (
	"id" serial PRIMARY KEY,
	"title" text NOT NULL,
	"date" text NOT NULL,
	"time" text NOT NULL,
	"description" text DEFAULT '' NOT NULL,
	"created_at" timestamp DEFAULT now()
);
